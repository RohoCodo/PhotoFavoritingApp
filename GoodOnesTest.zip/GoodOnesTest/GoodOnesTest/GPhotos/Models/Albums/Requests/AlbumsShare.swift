//
//  AlbumsShare.swift
//  GoodOnesTest
//
//  Created by Rohan Tyagi on 5/12/22.
//


import Foundation
import ObjectMapper

//internal class AlbumsShare {
//    internal init() {}
//
//    internal class Request : BaseMappable {
//        var id: String = ""
//        var sharedAlbumOptions: SharedAlbumOptions?
//
//        override func mapping(map: Map) {
//            sharedAlbumOptions <- map["sharedAlbumOptions"]
//        }
//    }
//
//    internal class Response : BaseMappable {
//        var shareInfo: ShareInfo?
//
//        override func mapping(map: Map) {
//            shareInfo <- map["shareInfo"]
//        }
//    }
//
//}
